package ro.mooncity.vehicles;

import com.google.gson.Gson;
import com.mojang.logging.LogUtils;
import com.mrcrayfish.vehicle.entity.VehicleProperties;
import net.minecraft.resources.ResourceLocation;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Field;
import java.nio.charset.StandardCharsets;
import java.util.Map;

/**
 * The vehicle mod loads /assets/<namespace>/vehicles/<id>.json with its own class loader. If that does not see our jar,
 * we parse our JSONs with the vehicle mod's own Gson and put them into its map. Safe to call many times.
 */
public final class PropertiesInjector {
    private PropertiesInjector() {}

    @SuppressWarnings("unchecked")
    public static void inject() {
        try {
            Field mapField = VehicleProperties.class.getDeclaredField("ID_TO_PROPERTIES");
            mapField.setAccessible(true);
            Map<ResourceLocation, VehicleProperties> map = (Map<ResourceLocation, VehicleProperties>) mapField.get(null);
            Field gsonField = VehicleProperties.class.getDeclaredField("GSON");
            gsonField.setAccessible(true);
            Gson gson = (Gson) gsonField.get(null);
            for (CarSpec s : CarList.CARS) {
                ResourceLocation id = new ResourceLocation(MoonVehicles.MODID, s.id());
                if (map.containsKey(id)) continue;
                try (InputStream in = PropertiesInjector.class.getResourceAsStream("/assets/" + MoonVehicles.MODID + "/vehicles/" + s.id() + ".json")) {
                    if (in == null) continue;
                    map.put(id, gson.fromJson(new InputStreamReader(in, StandardCharsets.UTF_8), VehicleProperties.class));
                } catch (IOException e) {
                    LogUtils.getLogger().error("Could not read properties for {}", s.id(), e);
                }
            }
        } catch (ReflectiveOperationException | RuntimeException e) {
            LogUtils.getLogger().error("MoonCity Vehicles: could not inject vehicle properties", e);
        }
    }
}
