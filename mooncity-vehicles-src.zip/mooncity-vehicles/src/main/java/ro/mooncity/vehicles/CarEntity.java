package ro.mooncity.vehicles;

import com.mrcrayfish.vehicle.entity.LandVehicleEntity;
import com.mrcrayfish.vehicle.init.ModSounds;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;

/** A normal MrCrayfish land vehicle (fuel, engine, driving, key, pumps all come from the vehicle mod); only the model differs. */
public class CarEntity extends LandVehicleEntity {
    public CarEntity(EntityType<? extends CarEntity> type, Level level) {
        super(type, level);
    }

    @Override
    public SoundEvent getEngineSound() {
        return ModSounds.ENTITY_MINI_BUS_ENGINE.get();
    }
}
