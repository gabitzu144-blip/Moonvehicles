package ro.mooncity.vehicles.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mrcrayfish.vehicle.client.EntityRayTracer;
import com.mrcrayfish.vehicle.client.model.SpecialModels;
import com.mrcrayfish.vehicle.client.render.AbstractLandVehicleRenderer;
import com.mrcrayfish.vehicle.entity.VehicleProperties;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.world.entity.EntityType;
import ro.mooncity.vehicles.CarEntity;

import java.util.function.Supplier;

/** Draws the car body from a mesh. Wheels/steering of the original mod are hidden (wheels are part of the mesh). */
public class MeshCarRenderer extends AbstractLandVehicleRenderer<CarEntity> {
    private final String id;
    private final EntityType<CarEntity> type;

    public MeshCarRenderer(String id, EntityType<CarEntity> type, Supplier<VehicleProperties> properties) {
        super(properties);
        this.id = id;
        this.type = type;
    }

    @Override
    protected void render(CarEntity entity, PoseStack pose, MultiBufferSource buffers, float partialTicks, int light) {
        MeshModel model = MeshModel.get(id);
        pose.pushPose();
        model.render(pose, buffers, light);
        pose.popPose();
    }

    /** Same fuel-door and key-port click areas the original vehicles have, so pumps and keys keep working. */
    @Override
    public EntityRayTracer.IRayTraceTransforms getRayTraceTransforms() {
        return (tracer, global, parts) -> {
            EntityRayTracer.createFuelPartTransforms(type, SpecialModels.FUEL_DOOR_CLOSED, parts, global);
            EntityRayTracer.createKeyPortTransforms(type, parts, global);
        };
    }
}
