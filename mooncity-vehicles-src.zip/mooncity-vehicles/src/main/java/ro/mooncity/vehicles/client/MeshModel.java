package ro.mooncity.vehicles.client;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import ro.mooncity.vehicles.MoonVehicles;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** A decimated car mesh loaded from assets/mooncityvehicles/cars/<id>/model.obj (+ materials.json + PNG textures). */
public final class MeshModel {
    private static final Map<String, MeshModel> CACHE = new HashMap<>();
    private static final ResourceLocation WHITE = new ResourceLocation("minecraft", "textures/misc/white.png");

    private static final class Group {
        ResourceLocation texture = WHITE;
        boolean blend;
        float r = 1, g = 1, b = 1, a = 1;
        float[] data = new float[0]; // 8 floats per vertex: x y z u v nx ny nz ; 3 vertices per triangle
        int vertices;
    }

    private final List<Group> groups = new ArrayList<>();

    public static MeshModel get(String id) {
        return CACHE.computeIfAbsent(id, MeshModel::load);
    }

    public static void clear() {
        CACHE.clear();
    }

    private static MeshModel load(String id) {
        MeshModel model = new MeshModel();
        try {
            var rm = Minecraft.getInstance().getResourceManager();
            String base = "cars/" + id + "/";
            JsonObject mats;
            try (var in = rm.getResource(new ResourceLocation(MoonVehicles.MODID, base + "materials.json")).orElseThrow().open()) {
                mats = JsonParser.parseReader(new InputStreamReader(in, StandardCharsets.UTF_8)).getAsJsonObject();
            }
            List<float[]> v = new ArrayList<>(), vt = new ArrayList<>(), vn = new ArrayList<>();
            Map<String, List<Float>> perMat = new java.util.LinkedHashMap<>();
            List<Float> cur = null;
            try (var in = rm.getResource(new ResourceLocation(MoonVehicles.MODID, base + "model.obj")).orElseThrow().open();
                 var br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8), 1 << 16)) {
                String line;
                while ((line = br.readLine()) != null) {
                    if (line.startsWith("v ")) v.add(parse(line, 3));
                    else if (line.startsWith("vt ")) vt.add(parse(line, 2));
                    else if (line.startsWith("vn ")) vn.add(parse(line, 3));
                    else if (line.startsWith("usemtl ")) cur = perMat.computeIfAbsent(line.substring(7).trim(), k -> new ArrayList<>());
                    else if (line.startsWith("f ") && cur != null) {
                        String[] p = line.split(" ");
                        for (int k = 1; k <= 3; k++) {
                            String[] idx = p[k].split("/");
                            float[] pos = v.get(Integer.parseInt(idx[0]) - 1);
                            float[] uv = vt.get(Integer.parseInt(idx[1]) - 1);
                            float[] n = vn.get(Integer.parseInt(idx[2]) - 1);
                            cur.add(pos[0]); cur.add(pos[1]); cur.add(pos[2]);
                            cur.add(uv[0]); cur.add(uv[1]);
                            cur.add(n[0]); cur.add(n[1]); cur.add(n[2]);
                        }
                    }
                }
            }
            for (var e : perMat.entrySet()) {
                Group g = new Group();
                JsonObject m = mats.getAsJsonObject(e.getKey());
                var col = m.getAsJsonArray("color");
                g.r = col.get(0).getAsFloat(); g.g = col.get(1).getAsFloat(); g.b = col.get(2).getAsFloat(); g.a = col.get(3).getAsFloat();
                g.blend = m.get("blend").getAsBoolean() || g.a < 0.99f;
                if (!m.get("texture").isJsonNull()) g.texture = new ResourceLocation(MoonVehicles.MODID, base + m.get("texture").getAsString());
                List<Float> l = e.getValue();
                g.data = new float[l.size()];
                for (int i = 0; i < g.data.length; i++) g.data[i] = l.get(i);
                g.vertices = g.data.length / 8;
                model.groups.add(g);
            }
        } catch (Exception ex) {
            com.mojang.logging.LogUtils.getLogger().error("MoonCity Vehicles: failed to load model {}", id, ex);
        }
        return model;
    }

    private static float[] parse(String line, int n) {
        String[] p = line.split(" ");
        float[] f = new float[n];
        for (int i = 0; i < n; i++) f[i] = Float.parseFloat(p[i + 1]);
        return f;
    }

    public void render(PoseStack pose, MultiBufferSource buffers, int light) {
        PoseStack.Pose last = pose.last();
        Matrix4f mat = last.pose();
        Matrix3f nrm = last.normal();
        for (Group g : groups) {
            RenderType rt = g.blend ? RenderType.entityTranslucent(g.texture) : RenderType.entityCutoutNoCull(g.texture);
            VertexConsumer vc = buffers.getBuffer(rt);
            float[] d = g.data;
            for (int t = 0; t + 2 < g.vertices; t += 3) {
                // the entity render types draw QUADS: repeat the last vertex of each triangle
                for (int k = 0; k < 4; k++) {
                    int o = (t + Math.min(k, 2)) * 8;
                    vc.vertex(mat, d[o], d[o + 1], d[o + 2])
                            .color(g.r, g.g, g.b, g.a)
                            .uv(d[o + 3], d[o + 4])
                            .overlayCoords(OverlayTexture.NO_OVERLAY)
                            .uv2(light)
                            .normal(nrm, d[o + 5], d[o + 6], d[o + 7])
                            .endVertex();
                }
            }
        }
    }
}
