package ro.mooncity.vehicles;

import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.server.ServerAboutToStartEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.LinkedHashMap;
import java.util.Map;

@Mod(MoonVehicles.MODID)
public class MoonVehicles {
    public static final String MODID = "mooncityvehicles";

    public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, MODID);
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, MODID);
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MODID);

    public static final Map<String, RegistryObject<EntityType<CarEntity>>> TYPES = new LinkedHashMap<>();
    public static final Map<String, RegistryObject<Item>> CAR_ITEMS = new LinkedHashMap<>();

    static {
        for (CarSpec s : CarList.CARS) {
            RegistryObject<EntityType<CarEntity>> type = ENTITIES.register(s.id(), () ->
                    EntityType.Builder.<CarEntity>of(CarEntity::new, MobCategory.MISC)
                            .sized(Math.max(s.width(), 1.0f), s.height())
                            .setTrackingRange(10).setUpdateInterval(1).setShouldReceiveVelocityUpdates(true)
                            .build(MODID + ":" + s.id()));
            TYPES.put(s.id(), type);
            CAR_ITEMS.put(s.id(), ITEMS.register(s.id(), () -> new CarItem(type, s.power(), new Item.Properties().stacksTo(1))));
        }
        TABS.register("cars", () -> CreativeModeTab.builder()
                .title(Component.translatable("itemGroup." + MODID))
                .icon(() -> new ItemStack(CAR_ITEMS.values().iterator().next().get()))
                .displayItems((params, out) -> CAR_ITEMS.values().forEach(i -> out.accept(i.get())))
                .build());
    }

    public MoonVehicles() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ENTITIES.register(bus);
        ITEMS.register(bus);
        TABS.register(bus);
        bus.addListener((FMLCommonSetupEvent e) -> e.enqueueWork(PropertiesInjector::inject));
        MinecraftForge.EVENT_BUS.addListener((ServerAboutToStartEvent e) -> PropertiesInjector.inject());
    }
}
