package ro.mooncity.vehicles;

import com.mrcrayfish.vehicle.init.ModItems;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.phys.Vec3;

import java.util.function.Supplier;

/** Right-click on the ground to spawn the car with an engine installed (tank empty: fill it with the vehicle mod's pump / jerry can). */
public class CarItem extends Item {
    private final Supplier<EntityType<CarEntity>> type;
    private final float power;

    public CarItem(Supplier<EntityType<CarEntity>> type, float power, Properties props) {
        super(props);
        this.type = type;
        this.power = power;
    }

    @Override
    public InteractionResult useOn(UseOnContext ctx) {
        var level = ctx.getLevel();
        if (level.isClientSide) return InteractionResult.SUCCESS;
        CarEntity car = type.get().create(level);
        if (car == null) return InteractionResult.FAIL;
        Vec3 p = ctx.getClickLocation();
        car.setPos(p.x, p.y, p.z);
        car.setYRot(ctx.getRotation());
        car.yRotO = ctx.getRotation();
        ItemStack engine = new ItemStack(power >= 1.5f ? ModItems.DIAMOND_LARGE_ENGINE.get()
                : power >= 1.2f ? ModItems.GOLD_LARGE_ENGINE.get() : ModItems.IRON_LARGE_ENGINE.get());
        car.setEngineStack(engine);
        car.setKeyNeeded(false);
        if (ctx.getPlayer() != null) car.setOwner(ctx.getPlayer().getUUID());
        level.addFreshEntity(car);
        if (ctx.getPlayer() == null || !ctx.getPlayer().getAbilities().instabuild) ctx.getItemInHand().shrink(1);
        return InteractionResult.CONSUME;
    }
}
