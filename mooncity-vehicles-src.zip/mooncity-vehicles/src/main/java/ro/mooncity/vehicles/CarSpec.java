package ro.mooncity.vehicles;

/** One car: id (file name), display name, hitbox width/height in blocks, power class (>=1.5 diamond engine, >=1.2 gold, else iron). */
public record CarSpec(String id, String name, float width, float height, float power) {}
