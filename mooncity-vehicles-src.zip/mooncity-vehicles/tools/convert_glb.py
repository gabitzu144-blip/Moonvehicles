#!/usr/bin/env python3
"""
GLB -> lightweight OBJ + PNG textures + materials.json for the MoonCity Vehicles mod.

Usage:
  python3 convert_glb.py <in.glb> <out_dir> --id my_car [--tris 40000] [--length 4.4] [--flip] [--tex 512]

Output (out_dir/<id>/):
  model.obj        decimated mesh (Y up, front = +Z, ground = y 0, centered on X/Z, 1 unit = 1 block)
  materials.json   { "mat_0": {"color":[r,g,b,a], "texture":"mat_0.png"|null, "blend":bool}, ... }
  mat_N.png        textures (downscaled)
  info.json        size in blocks (length/width/height), triangle counts
  preview.png      top + side silhouette, to check the front direction
"""
import argparse, json, math, os, struct, sys, io
import numpy as np
from PIL import Image, ImageDraw

CT = {5120: np.int8, 5121: np.uint8, 5122: np.int16, 5123: np.uint16, 5125: np.uint32, 5126: np.float32}
NC = {"SCALAR": 1, "VEC2": 2, "VEC3": 3, "VEC4": 4, "MAT4": 16}


def load_glb(path):
    with open(path, "rb") as f:
        data = f.read()
    magic, ver, _ = struct.unpack_from("<4sII", data, 0)
    assert magic == b"glTF", "not a GLB"
    off, js, binchunk = 12, None, b""
    while off < len(data):
        clen, ctype = struct.unpack_from("<II", data, off)
        chunk = data[off + 8: off + 8 + clen]
        if ctype == 0x4E4F534A:
            js = json.loads(chunk)
        elif ctype == 0x004E4942:
            binchunk = chunk
        off += 8 + clen
    return js, binchunk


def read_accessor(js, binb, idx):
    acc = js["accessors"][idx]
    bv = js["bufferViews"][acc["bufferView"]] if "bufferView" in acc else None
    dt = np.dtype(CT[acc["componentType"]])
    n = NC[acc["type"]]
    count = acc["count"]
    if bv is None:
        return np.zeros((count, n), dtype=np.float32)
    start = bv.get("byteOffset", 0) + acc.get("byteOffset", 0)
    stride = bv.get("byteStride", 0) or dt.itemsize * n
    if stride == dt.itemsize * n:
        arr = np.frombuffer(binb, dtype=dt, count=count * n, offset=start).reshape(count, n)
    else:
        raw = np.frombuffer(binb, dtype=np.uint8, count=stride * (count - 1) + dt.itemsize * n, offset=start)
        arr = np.lib.stride_tricks.as_strided(raw, shape=(count, dt.itemsize * n), strides=(stride, 1))
        arr = np.ascontiguousarray(arr).view(dt).reshape(count, n)
    if acc.get("normalized"):
        info = np.iinfo(dt)
        arr = np.maximum(arr.astype(np.float32) / float(info.max), -1.0)
    return arr


def node_matrix(node):
    if "matrix" in node:
        return np.array(node["matrix"], dtype=np.float64).reshape(4, 4).T
    t = np.array(node.get("translation", [0, 0, 0]), dtype=np.float64)
    q = node.get("rotation", [0, 0, 0, 1])
    s = np.array(node.get("scale", [1, 1, 1]), dtype=np.float64)
    x, y, z, w = q
    R = np.array([
        [1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)],
        [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)],
        [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)]])
    M = np.eye(4)
    M[:3, :3] = R * s
    M[:3, 3] = t
    return M


def collect(js, binb):
    """Returns dict material_index -> (pos Nx3, nrm Nx3, uv Nx2, tris Mx3) in world space."""
    scene = js["scenes"][js.get("scene", 0)]
    out = {}
    stack = [(n, np.eye(4)) for n in scene["nodes"]]
    while stack:
        ni, parent = stack.pop()
        node = js["nodes"][ni]
        M = parent @ node_matrix(node)
        for c in node.get("children", []):
            stack.append((c, M))
        if "mesh" not in node:
            continue
        NM = np.linalg.inv(M[:3, :3]).T
        for prim in js["meshes"][node["mesh"]]["primitives"]:
            if prim.get("mode", 4) != 4 or "indices" not in prim:
                continue
            attrs = prim["attributes"]
            pos = read_accessor(js, binb, attrs["POSITION"]).astype(np.float64)
            nrm = read_accessor(js, binb, attrs["NORMAL"]).astype(np.float64) if "NORMAL" in attrs else np.tile([0, 1, 0.0], (len(pos), 1))
            uv = read_accessor(js, binb, attrs["TEXCOORD_0"]).astype(np.float64) if "TEXCOORD_0" in attrs else np.zeros((len(pos), 2))
            idx = read_accessor(js, binb, prim["indices"]).reshape(-1).astype(np.int64).reshape(-1, 3)
            wp = pos @ M[:3, :3].T + M[:3, 3]
            wn = nrm @ NM.T
            ln = np.linalg.norm(wn, axis=1, keepdims=True)
            wn = wn / np.where(ln == 0, 1, ln)
            mat = prim.get("material", -1)
            out.setdefault(mat, []).append((wp, wn, uv, idx))
    merged = {}
    for mat, parts in out.items():
        P, N, U, T, base = [], [], [], [], 0
        for p, n, u, t in parts:
            P.append(p); N.append(n); U.append(u); T.append(t + base); base += len(p)
        merged[mat] = (np.vstack(P), np.vstack(N), np.vstack(U), np.vstack(T))
    return merged


def orient(merged, length, flip):
    allp = np.vstack([v[0] for v in merged.values()])
    mn, mx = allp.min(0), allp.max(0)
    ext = mx - mn
    # glTF is Y up. Make the longest horizontal axis Z.
    rot = np.eye(3)
    if ext[0] > ext[2]:
        rot = np.array([[0, 0, 1], [0, 1, 0], [-1, 0, 0]], dtype=np.float64)  # X -> Z
    if flip:
        rot = np.array([[-1, 0, 0], [0, 1, 0], [0, 0, -1]], dtype=np.float64) @ rot
    rp = allp @ rot.T
    mn, mx = rp.min(0), rp.max(0)
    scale = length / (mx[2] - mn[2])
    center = np.array([(mn[0] + mx[0]) / 2, mn[1], (mn[2] + mx[2]) / 2])
    res = {}
    for mat, (p, n, u, t) in merged.items():
        res[mat] = (((p @ rot.T) - center) * scale, n @ rot.T, u, t)
    return res


def cluster_decimate(merged, target):
    total = sum(len(v[3]) for v in merged.values())
    if total <= target:
        return merged, total
    allp = np.vstack([v[0] for v in merged.values()])
    mn, mx = allp.min(0), allp.max(0)
    diag = np.linalg.norm(mx - mn)

    def run(h, build):
        res, count = {}, 0
        for mat, (p, n, u, t) in merged.items():
            cell = np.floor((p - mn) / h).astype(np.int64)
            key = (cell[:, 0] * 4096 + cell[:, 1]) * 4096 + cell[:, 2]
            uniq, first, inv = np.unique(key, return_index=True, return_inverse=True)
            nt = inv[t]
            ok = (nt[:, 0] != nt[:, 1]) & (nt[:, 1] != nt[:, 2]) & (nt[:, 0] != nt[:, 2])
            nt = nt[ok]
            count += len(nt)
            if build:
                cnt = np.bincount(inv, minlength=len(uniq)).astype(np.float64)
                np_ = np.stack([np.bincount(inv, weights=p[:, k], minlength=len(uniq)) for k in range(3)], 1) / cnt[:, None]
                nn = np.stack([np.bincount(inv, weights=n[:, k], minlength=len(uniq)) for k in range(3)], 1)
                ln = np.linalg.norm(nn, axis=1, keepdims=True)
                nn = nn / np.where(ln == 0, 1, ln)
                res[mat] = (np_, nn, u[first], nt)
        return res, count

    lo, hi = diag / 4000.0, diag / 8.0
    for _ in range(14):
        mid = math.sqrt(lo * hi)
        _, c = run(mid, False)
        if c > target:
            lo = mid
        else:
            hi = mid
    res, c = run(hi, True)
    return res, c


def save_texture(js, binb, tex_index, out_path, maxsize):
    tex = js["textures"][tex_index]
    img = js["images"][tex["source"]]
    bv = js["bufferViews"][img["bufferView"]]
    raw = binb[bv.get("byteOffset", 0): bv.get("byteOffset", 0) + bv["byteLength"]]
    im = Image.open(io.BytesIO(raw)).convert("RGBA")
    if max(im.size) > maxsize:
        im.thumbnail((maxsize, maxsize), Image.LANCZOS)
    im.save(out_path)


def write_obj(path, merged, mat_names):
    voff = 0
    with open(path, "w") as f:
        f.write("# MoonCity Vehicles - generated\n")
        for mat, (p, n, u, t) in merged.items():
            name = mat_names[mat]
            f.write(f"o {name}\nusemtl {name}\n")
            f.write("\n".join(f"v {a:.4f} {b:.4f} {c:.4f}" for a, b, c in p) + "\n")
            f.write("\n".join(f"vt {a:.4f} {1 - b:.4f}" for a, b in u) + "\n")
            f.write("\n".join(f"vn {a:.3f} {b:.3f} {c:.3f}" for a, b, c in n) + "\n")
            tt = t + 1 + voff
            f.write("\n".join(f"f {a}/{a}/{a} {b}/{b}/{b} {c}/{c}/{c}" for a, b, c in tt) + "\n")
            voff += len(p)


def preview(path, merged):
    allp = np.vstack([v[0] for v in merged.values()])
    W = 900
    img = Image.new("RGB", (W, 520), (20, 20, 28))
    d = ImageDraw.Draw(img)
    mn, mx = allp.min(0), allp.max(0)
    s = 380 / max(mx[2] - mn[2], mx[1] - mn[1], 1e-6)
    sub = allp[:: max(1, len(allp) // 40000)]
    for x, y, z in sub:
        # side view: +Z (front) to the right
        d.point((60 + (z - mn[2]) * s, 250 - (y - mn[1]) * s), fill=(0, 220, 255))
        # top view (below)
        d.point((60 + (z - mn[2]) * s, 420 + x * s), fill=(255, 200, 0))
    d.text((10, 8), "FRONT must be on the RIGHT (+Z). If not, re-run with --flip", fill=(255, 255, 255))
    img.save(path)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("glb"); ap.add_argument("out")
    ap.add_argument("--id", required=True)
    ap.add_argument("--tris", type=int, default=40000)
    ap.add_argument("--length", type=float, default=4.4, help="car length in blocks")
    ap.add_argument("--flip", action="store_true")
    ap.add_argument("--tex", type=int, default=512)
    a = ap.parse_args()

    js, binb = load_glb(a.glb)
    merged = collect(js, binb)
    before = sum(len(v[3]) for v in merged.values())
    merged = orient(merged, a.length, a.flip)
    merged, after = cluster_decimate(merged, a.tris)

    out = os.path.join(a.out, a.id)
    os.makedirs(out, exist_ok=True)
    mats, names = {}, {}
    for mat in merged:
        name = f"mat_{mat}" if mat >= 0 else "mat_default"
        names[mat] = name
        color, tex, blend = [1, 1, 1, 1], None, False
        if mat >= 0:
            m = js["materials"][mat]
            pbr = m.get("pbrMetallicRoughness", {})
            color = pbr.get("baseColorFactor", [1, 1, 1, 1])
            blend = m.get("alphaMode") == "BLEND"
            if "baseColorTexture" in pbr:
                try:
                    save_texture(js, binb, pbr["baseColorTexture"]["index"], os.path.join(out, name + ".png"), a.tex)
                    tex = name + ".png"
                except Exception as e:
                    print("texture failed", name, e, file=sys.stderr)
        mats[name] = {"color": color, "texture": tex, "blend": blend}
    write_obj(os.path.join(out, "model.obj"), merged, names)
    json.dump(mats, open(os.path.join(out, "materials.json"), "w"), indent=1)
    allp = np.vstack([v[0] for v in merged.values()])
    mn, mx = allp.min(0), allp.max(0)
    info = {"id": a.id, "tris_before": before, "tris_after": after,
            "width": round(float(mx[0] - mn[0]), 3), "height": round(float(mx[1] - mn[1]), 3),
            "length": round(float(mx[2] - mn[2]), 3)}
    json.dump(info, open(os.path.join(out, "info.json"), "w"), indent=1)
    preview(os.path.join(out, "preview.png"), merged)
    print(json.dumps(info))


if __name__ == "__main__":
    main()
