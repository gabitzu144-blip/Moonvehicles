# MoonCity Vehicles (Forge 1.20.1)

Mașini 3D (din GLB) pentru MrCrayfish Vehicle (Unofficial) + vitezometru + HUD MoonCity (logo, ora, ore jucate, cash din Good Ol Currency).

## Compilare
1. Pune în `libs/` două jar-uri, cu exact aceste nume:
   - `vehicle-1.20.1.jar`   (jar-ul MrCrayfish Vehicle Unofficial pe care l-ai încărcat)
   - `framework-1.20.1.jar` (MrCrayfish Framework 1.20.1 – cerut de mod vehicule)
2. JDK 17, apoi: `./gradlew build` (ai nevoie de Gradle wrapper; sau `gradle wrapper` o dată).
3. Jar-ul rezultat: `build/libs/mooncityvehicles-1.0.0.jar` → în `mods/` (client ȘI server), alături de vehicle + framework.

## Folosire
- Tab creativ „MoonCity Vehicles”: click dreapta pe sol cu itemul unei mașini o pune cu motor montat.
- Benzina: exact ca la mașinile din mod (pompă / jerry can pe clapeta de combustibil). Rezervorul pornește gol.
- Vitezometrul apare când ești într-un vehicul din mod (și la cele originale).

## Mașini noi / reglaje
- `tools/build_all.py`: lista `CARS` (lungime în blocuri, nr. triunghiuri, flip dacă mașina e cu spatele).
  Rulează: `python3 tools/build_all.py /cale/spre/glb-uri` (necesită numpy + pillow).
- Poziția scaunelor / roților / clapetei: `src/main/resources/assets/mooncityvehicles/vehicles/<id>.json`.
