package ro.mooncity.vehicles.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.network.protocol.game.ServerboundClientCommandPacket;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.stats.Stats;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.scores.Objective;
import net.minecraft.world.scores.Scoreboard;
import net.minecraftforge.client.gui.overlay.ForgeGui;
import net.minecraftforge.common.capabilities.ForgeCapabilities;
import net.minecraftforge.registries.ForgeRegistries;
import ro.mooncity.vehicles.MoonVehicles;

import java.text.NumberFormat;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Locale;
import java.util.Map;

/**
 * MoonCity HUD (top-right): logo, players online, ID, Romania time, hours played, hour progress bar,
 * CASH (coins/bills of Good Ol' Currency in inventory + wallets) and CARD (scoreboard objective "bank", only if the server has it).
 */
public final class MoonHud {
    private static final ResourceLocation LOGO = new ResourceLocation(MoonVehicles.MODID, "textures/gui/logo.png");
    private static final ZoneId RO = ZoneId.of("Europe/Bucharest");
    private static final String CURRENCY_NS = "good_ol_currency_reforged";
    /** Count the "fool" bills as money? (false = only the normal ones) */
    private static final boolean COUNT_FOOL = false;
    /** Scoreboard objective the server can fill with the player's bank money (whole dollars). */
    private static final String BANK_OBJECTIVE = "bank";

    /** value in cents */
    private static final Map<String, Long> VALUES = Map.ofEntries(
            Map.entry("one_cent", 1L), Map.entry("five_cent", 5L), Map.entry("ten_cent", 10L),
            Map.entry("twentyfive_cent", 25L), Map.entry("thirty_cent", 30L), Map.entry("fifty_cent", 50L),
            Map.entry("one_dollar", 100L), Map.entry("five_dollar", 500L), Map.entry("ten_dollar", 1000L),
            Map.entry("twenty_dollar", 2000L), Map.entry("fifty_dollar", 5000L), Map.entry("onehundred_dollar", 10000L),
            Map.entry("fool_dollar", 100L), Map.entry("fool_five_dollar", 500L), Map.entry("fool_ten_dollar", 1000L),
            Map.entry("fool_twenty_dollar", 2000L), Map.entry("fool_fifty_dollar", 5000L), Map.entry("fool_onehundred_dollar", 10000L));

    private static final int GOLD = 0xFFFFC21A, SILVER = 0xFFC9D6E8, DIM = 0xFF8D99AB, GREEN = 0xFF3DDC57, BLUE = 0xFF6FA8FF;
    private static long lastStatsRequest;

    private MoonHud() {}

    public static void render(ForgeGui gui, GuiGraphics g, float partial, int w, int h) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null || mc.options.hideGui || mc.options.renderDebug) return;
        Font font = mc.font;
        ClientPacketListener conn = mc.getConnection();

        // ask the server for the stats (play time) now and then
        long now = System.currentTimeMillis();
        if (conn != null && now - lastStatsRequest > 30_000) {
            lastStatsRequest = now;
            conn.send(new ServerboundClientCommandPacket(ServerboundClientCommandPacket.Action.REQUEST_STATS));
        }
        long ticks = mc.player.getStats().getValue(Stats.CUSTOM.get(Stats.PLAY_TIME));
        long mins = ticks / 20 / 60;
        String hours = (mins / 60) + ":" + String.format("%02d", mins % 60);

        ZonedDateTime t = ZonedDateTime.now(RO);
        String time = String.format("%02d:%02d", t.getHour(), t.getMinute());
        int players = conn == null ? 1 : conn.getOnlinePlayers().size();
        double hourFrac = (t.getMinute() * 60 + t.getSecond()) / 3600.0;

        int pw = 178;
        int x = w - pw - 6, y = 6;
        boolean hasBank = false;
        long bank = 0;
        Scoreboard sb = mc.level.getScoreboard();
        Objective obj = sb.getObjective(BANK_OBJECTIVE);
        if (obj != null && sb.hasPlayerScore(mc.player.getScoreboardName(), obj)) {
            hasBank = true;
            bank = sb.getOrCreatePlayerScore(mc.player.getScoreboardName(), obj).getScore();
        }
        int ph = 82 + (hasBank ? 14 : 0);
        g.fill(x, y, x + pw, y + ph, 0xB30B0E14);
        g.renderOutline(x, y, pw, ph, 0xFF2A3342);

        // logo + title
        g.blit(LOGO, x + 6, y + 5, 28, 32, 0f, 0f, 128, 147, 128, 147);
        g.pose().pushPose();
        g.pose().translate(x + 40, y + 9, 0);
        g.pose().scale(1.7f, 1.7f, 1f);
        g.drawString(font, "MOONCITY", 0, 0, SILVER, true);
        g.pose().popPose();
        g.drawString(font, "ROLEPLAY", x + 41, y + 27, DIM, false);

        // four stats
        int cw = pw / 4;
        stat(g, font, x + 0 * cw, y + 42, cw, Integer.toString(players), "PLAYERS");
        stat(g, font, x + 1 * cw, y + 42, cw, Integer.toString(mc.player.getId()), "ID");
        stat(g, font, x + 2 * cw, y + 42, cw, time, "ORA");
        stat(g, font, x + 3 * cw, y + 42, cw, hours, "ORE");

        // hour progress
        g.fill(x + 6, y + 63, x + pw - 6, y + 65, 0xFF2A3342);
        g.fill(x + 6, y + 63, x + 6 + (int) ((pw - 12) * hourFrac), y + 65, BLUE);

        // money
        money(g, font, x, y + 69, pw, "$", format(cash(mc.player.getInventory())), "CASH");
        if (hasBank) money(g, font, x, y + 83, pw, "$", NumberFormat.getIntegerInstance(Locale.US).format(bank), "CARD");
    }

    private static void stat(GuiGraphics g, Font font, int x, int y, int w, String value, String label) {
        g.drawCenteredString(font, value, x + w / 2, y, 0xFFFFFFFF);
        g.pose().pushPose();
        g.pose().translate(x + w / 2f, y + 11, 0);
        g.pose().scale(0.6f, 0.6f, 1f);
        g.drawString(font, label, -font.width(label) / 2, 0, DIM, false);
        g.pose().popPose();
    }

    private static void money(GuiGraphics g, Font font, int x, int y, int pw, String sign, String amount, String label) {
        int right = x + pw - 6;
        g.drawString(font, label, right - font.width(label), y, DIM, false);
        int amountRight = right - font.width(label) - 6;
        g.drawString(font, amount, amountRight - font.width(amount), y, 0xFFFFFFFF, true);
        g.drawString(font, sign, amountRight - font.width(amount) - font.width(sign) - 2, y, GREEN, true);
    }

    private static String format(long cents) {
        String whole = NumberFormat.getIntegerInstance(Locale.US).format(cents / 100);
        return cents % 100 == 0 ? whole : whole + "." + String.format("%02d", cents % 100);
    }

    /** Value in cents of all Good Ol' Currency coins/bills in the inventory, including inside wallets. */
    private static long cash(Inventory inv) {
        long total = 0;
        for (int i = 0; i < inv.getContainerSize(); i++) {
            ItemStack s = inv.getItem(i);
            if (s.isEmpty()) continue;
            total += value(s);
            if (isCurrency(s, "wallet")) {
                total += s.getCapability(ForgeCapabilities.ITEM_HANDLER).map(hd -> {
                    long sum = 0;
                    for (int k = 0; k < hd.getSlots(); k++) sum += value(hd.getStackInSlot(k));
                    return sum;
                }).orElse(0L);
            }
        }
        return total;
    }

    private static boolean isCurrency(ItemStack s, String path) {
        ResourceLocation id = ForgeRegistries.ITEMS.getKey(s.getItem());
        return id != null && id.getNamespace().equals(CURRENCY_NS) && id.getPath().equals(path);
    }

    private static long value(ItemStack s) {
        if (s.isEmpty()) return 0;
        ResourceLocation id = ForgeRegistries.ITEMS.getKey(s.getItem());
        if (id == null || !id.getNamespace().equals(CURRENCY_NS)) return 0;
        if (!COUNT_FOOL && id.getPath().startsWith("fool_")) return 0;
        Long v = VALUES.get(id.getPath());
        return v == null ? 0 : v * s.getCount();
    }
}
