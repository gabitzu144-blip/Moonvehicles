package ro.mooncity.vehicles.client;

import com.mrcrayfish.vehicle.entity.PoweredVehicleEntity;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraftforge.client.gui.overlay.ForgeGui;

/** Pixel-style speedometer + fuel gauge, shown while riding any MrCrayfish powered vehicle. */
public final class SpeedometerOverlay {
    private static final double MAX_KMH = 240.0;
    private static final int CYAN = 0xFF22E0FF, CYAN_DIM = 0xFF0E3A44, GREY = 0xFF3A3D45, WHITE = 0xFFFFFFFF;
    private static final int RED = 0xFFFF2A4A, RED_DIM = 0xFF5A1A28, YELLOW = 0xFFFFC21A, YELLOW_DIM = 0xFF4A3A0E;
    private static double smoothKmh;

    private SpeedometerOverlay() {}

    public static void render(ForgeGui gui, GuiGraphics g, float partial, int w, int h) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui) return;
        if (!(mc.player.getVehicle() instanceof PoweredVehicleEntity car)) return;

        double kmh = Math.abs(car.getKilometersPreHour());
        smoothKmh += (kmh - smoothKmh) * 0.25;
        int shown = (int) Math.round(smoothKmh < 0.5 ? 0 : smoothKmh);
        double frac = Math.min(1.0, smoothKmh / MAX_KMH);

        float cap = car.getFuelCapacity();
        float fuel = car.getCurrentFuel();
        double fuelFrac = cap <= 0 ? 0 : Math.max(0, Math.min(1, fuel / cap));

        // scale the whole gauge down on short screens so it never overlaps the MoonCity panel at the top
        float sc = Math.max(0.4f, Math.min(1f, (h - 112f) / 142f));
        g.pose().pushPose();
        g.pose().translate(w - 120, h - 4, 0);
        g.pose().scale(sc, sc, 1f);
        int cx = 0, cy = -76;
        Font font = mc.font;

        // main gauge: 270 degrees, from lower-left over the top to lower-right
        arc(g, cx, cy, 58, 100, frac, CYAN, CYAN_DIM, 0.82, RED, RED_DIM);
        ticks(g, cx, cy, 66, 10);

        // speed number
        g.pose().pushPose();
        g.pose().translate(cx, cy - 18, 0);
        g.pose().scale(3f, 3f, 1f);
        String s = Integer.toString(shown);
        g.drawString(font, s, -font.width(s) / 2, 0, WHITE, true);
        g.pose().popPose();
        g.drawCenteredString(font, "KM/H", cx, cy + 12, 0xFF9AA4B2);

        // gear box
        String gear = gear(car, smoothKmh);
        g.fill(cx - 17, cy + 24, cx + 17, cy + 38, 0xFF0B2A33);
        g.renderOutline(cx - 17, cy + 24, 34, 14, 0xFF1D7C8F);
        g.drawCenteredString(font, gear, cx, cy + 28, WHITE);

        // fuel gauge (left)
        int fx = cx - 105, fy = cy + 22;
        boolean low = fuelFrac <= 0.2;
        arc(g, fx, fy, 24, 50, fuelFrac, low ? RED : YELLOW, low ? RED_DIM : YELLOW_DIM, 2.0, RED, RED_DIM);
        g.drawCenteredString(font, "FUEL", fx, fy - 17, 0xFF9AA4B2);
        g.pose().pushPose();
        g.pose().translate(fx, fy - 6, 0);
        g.pose().scale(1.5f, 1.5f, 1f);
        String pct = Math.round(fuelFrac * 100) + "%";
        g.drawString(font, pct, -font.width(pct) / 2, 0, low ? RED : YELLOW, true);
        g.pose().popPose();
        g.pose().pushPose();
        g.pose().translate(fx, fy + 8, 0);
        g.pose().scale(0.6f, 0.6f, 1f);
        String liters = Math.round(fuel) + "/" + Math.round(cap) + "L";
        g.drawString(font, liters, -font.width(liters) / 2, 0, 0xFFB8C0CC, false);
        g.pose().popPose();
        g.pose().popPose();
    }

    private static String gear(PoweredVehicleEntity car, double kmh) {
        if (car.getSpeed() < -0.01f) return "R";
        if (kmh < 1.0) return "N";
        int d = (int) Math.min(6, 1 + kmh / (MAX_KMH / 6.0 * 0.75));
        return "D" + d;
    }

    /** Draws a segmented 270-degree arc; segments up to `frac` are lit, the last part (from `redFrom`) is red. */
    private static void arc(GuiGraphics g, int cx, int cy, int r, int n, double frac, int on, int off, double redFrom, int red, int redOff) {
        int lit = (int) Math.round(frac * n);
        for (int i = 0; i < n; i++) {
            double t = n == 1 ? 0 : (double) i / (n - 1);
            double a = Math.toRadians(225 - 270 * t);
            int x = (int) Math.round(cx + r * Math.cos(a));
            int y = (int) Math.round(cy - r * Math.sin(a));
            boolean isRed = t >= redFrom;
            int color = i < lit ? (isRed ? red : on) : (isRed ? redOff : off);
            g.fill(x - 1, y - 1, x + 2, y + 2, color);
            int x2 = (int) Math.round(cx + (r - 3) * Math.cos(a));
            int y2 = (int) Math.round(cy - (r - 3) * Math.sin(a));
            g.fill(x2 - 1, y2 - 1, x2 + 2, y2 + 2, color);
        }
    }

    private static void ticks(GuiGraphics g, int cx, int cy, int r, int count) {
        for (int i = 0; i <= count; i++) {
            double a = Math.toRadians(225 - 270.0 * i / count);
            int x = (int) Math.round(cx + r * Math.cos(a));
            int y = (int) Math.round(cy - r * Math.sin(a));
            g.fill(x - 1, y - 1, x + 2, y + 2, i >= count * 0.82 ? RED : 0xFFD0D4DA);
        }
    }
}
