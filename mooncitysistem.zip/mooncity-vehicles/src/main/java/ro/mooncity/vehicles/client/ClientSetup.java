package ro.mooncity.vehicles.client;

import com.mrcrayfish.vehicle.client.EntityRayTracer;
import com.mrcrayfish.vehicle.client.render.AbstractVehicleRenderer;
import com.mrcrayfish.vehicle.client.render.EntityVehicleRenderer;
import com.mrcrayfish.vehicle.client.render.VehicleRenderRegistry;
import com.mrcrayfish.vehicle.entity.VehicleProperties;
import net.minecraft.world.entity.EntityType;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.RegisterClientReloadListenersEvent;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import ro.mooncity.vehicles.CarEntity;
import ro.mooncity.vehicles.CarList;
import ro.mooncity.vehicles.CarSpec;
import ro.mooncity.vehicles.MoonVehicles;
import ro.mooncity.vehicles.PropertiesInjector;

import java.util.function.Function;
import java.util.function.Supplier;

@Mod.EventBusSubscriber(modid = MoonVehicles.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientSetup {
    private ClientSetup() {}

    @SubscribeEvent
    public static void clientSetup(FMLClientSetupEvent e) {
        e.enqueueWork(PropertiesInjector::inject);
    }

    @SubscribeEvent
    public static void reload(RegisterClientReloadListenersEvent e) {
        e.registerReloadListener((net.minecraft.server.packs.resources.ResourceManagerReloadListener) rm -> MeshModel.clear());
    }

    @SubscribeEvent
    public static void overlays(RegisterGuiOverlaysEvent e) {
        e.registerAboveAll("speedometer", SpeedometerOverlay::render);
        e.registerAboveAll("mooncity_hud", MoonHud::render);
    }

    /** Same three steps the vehicle mod does for its own vehicles (renderer, render registry, ray-trace areas). */
    @SubscribeEvent
    @SuppressWarnings({"unchecked", "rawtypes"})
    public static void renderers(EntityRenderersEvent.RegisterRenderers e) {
        for (CarSpec s : CarList.CARS) {
            EntityType<CarEntity> type = MoonVehicles.TYPES.get(s.id()).get();
            Function<Supplier<VehicleProperties>, AbstractVehicleRenderer<CarEntity>> fn = sup -> new MeshCarRenderer(s.id(), type, sup);
            AbstractVehicleRenderer<CarEntity> renderer = fn.apply(() -> VehicleProperties.get(type));
            e.registerEntityRenderer(type, ctx -> new EntityVehicleRenderer<>(ctx, renderer));
            VehicleRenderRegistry.registerVehicleRendererFunction(type, (Function) fn, renderer);
            var transforms = renderer.getRayTraceTransforms();
            if (transforms != null) EntityRayTracer.instance().registerTransforms(type, transforms);
        }
    }
}
